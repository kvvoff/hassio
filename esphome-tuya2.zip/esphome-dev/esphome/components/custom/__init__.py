import esphome.codegen as cg

custom_ns = cg.esphome_ns.namespace('custom')
