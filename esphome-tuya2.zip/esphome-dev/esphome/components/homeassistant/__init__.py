import esphome.codegen as cg

homeassistant_ns = cg.esphome_ns.namespace('homeassistant')
