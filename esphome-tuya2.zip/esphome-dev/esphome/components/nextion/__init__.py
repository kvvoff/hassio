import esphome.codegen as cg

nextion_ns = cg.esphome_ns.namespace('nextion')
