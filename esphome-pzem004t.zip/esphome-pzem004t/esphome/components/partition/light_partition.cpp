#include "light_partition.h"
#include "esphome/core/log.h"

namespace esphome {
namespace partition {

static const char *TAG = "partition.light";

}  // namespace partition
}  // namespace esphome
