import esphome.codegen as cg

gpio_ns = cg.esphome_ns.namespace('gpio')
