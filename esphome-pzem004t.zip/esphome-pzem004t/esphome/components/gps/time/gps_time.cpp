#include "gps_time.h"
#include "esphome/core/log.h"

namespace esphome {
namespace gps {

static const char *TAG = "gps.time";

}  // namespace gps
}  // namespace esphome
