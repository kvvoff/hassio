import esphome.codegen as cg

mqtt_subscribe_ns = cg.esphome_ns.namespace('mqtt_subscribe')
