#include "remote_transmitter.h"
#include "esphome/core/log.h"
#include "esphome/core/application.h"

namespace esphome {
namespace remote_transmitter {

static const char *TAG = "remote_transmitter";

}  // namespace remote_transmitter
}  // namespace esphome
