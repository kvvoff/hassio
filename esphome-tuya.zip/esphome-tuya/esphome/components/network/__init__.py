# Dummy package to allow components to depend on network
